<!DOCTYPE html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="vi"> <![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8" lang="vi"> <![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9" lang="vi"> <![endif]-->
<!--[if IE 9 ]><html class="ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="vi"> <!--<![endif]-->
<head lang="vi">

	<!-- Basic page needs ================================================== -->

	<!-- Title and description ================================================== -->
	<title>
		404 Không tìm thấy trang &ndash; Mac Cafe
	</title>

	

	<!-- Product meta ================================================== -->
	

  <meta property="og:url" content="">
  <meta property="og:site_name" content="Mac Cafe">
	
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TGTQNMQ');</script>
<!-- End Google Tag Manager -->


	<!-- Helpers ================================================== -->
	<link rel="canonical" href="">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name='revisit-after' content='1 days' />
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta http-equiv="content-language" content="vi" />
	<meta name="robots" content="noodp,index,follow" />
	<meta name='revisit-after' content='1 days' />
	<!-- Favicon -->
	<link rel="shortcut icon" href="//bizweb.dktcdn.net/100/183/542/themes/548520/assets/favicon.png?1542697260528" type="image/x-icon" />
	<!-- Scripts -->
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  
	<!-- Styles -->

	<!-- Header hook for plugins ================================================== -->
	<script>
var Bizweb = Bizweb || {};
Bizweb.store = 'maccafe.bizwebvietnam.net';
Bizweb.id='183542';
Bizweb.theme = {"id":548520,"role":"main","name":"Mac Cafe - Web"};
Bizweb.template = '404';
</script>

<script>
(function() {
function asyncLoad() {
var urls = ["https://facebookinbox.bizwebapps.vn/Script/index?store=maccafe.bizwebvietnam.net"];
for (var i = 0; i < urls.length; i++) {
var s = document.createElement('script');
s.type = 'text/javascript';
s.async = true;
s.src = urls[i];
s.src = urls[i];
var x = document.getElementsByTagName('script')[0];
x.parentNode.insertBefore(s, x);
}
}
window.attachEvent ? window.attachEvent('onload', asyncLoad) : window.addEventListener('load', asyncLoad, false);
})();
</script>

<script type='text/javascript'>
(function() {
var log = document.createElement('script'); log.type = 'text/javascript'; log.async = true;
log.src = '//stats.bizweb.vn/delivery/183542.js?lang=vi';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(log, s);
})();
</script>



<!--Facebook Pixel Code-->
<script>
!function(f, b, e, v, n, t, s){
if (f.fbq) return; n = f.fbq = function(){
n.callMethod?
n.callMethod.apply(n, arguments):n.queue.push(arguments)}; if (!f._fbq) f._fbq = n;
n.push = n; n.loaded = !0; n.version = '2.0'; n.queue =[]; t = b.createElement(e); t.async = !0;
t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s)}
(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '790562244405202'); // Insert your pixel ID here.
fbq('track', 'PageView');
</script>
<noscript><img height = '1' width = '1' style = 'display:none'
src = 'https://www.facebook.com/tr?id=790562244405202&ev=PageView&noscript=1'
/></noscript>
<!--DO NOT MODIFY-->
<!--End Facebook Pixel Code-->


	<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->
	<!--[if IE 7]>
<link href='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/font-awesome-ie7.css?1542697260528' rel='stylesheet' type='text/css' />
<![endif]-->
	<!--[if lt IE 9]>
<script src='//html5shiv.googlecode.com/svn/trunk/html5.js' type='text/javascript'></script>
<![endif]-->
	
	<div class="hidden">
	<div id="popup-cart-desktop" style="display: none;">
		<div class="title-popup-cart">
			<span class="border_check"><i class="fa fa-check" aria-hidden="true"></i></span> <p>Sản phẩm <span class="cart-popup-name"></span>đã thêm vào giỏ hàng</p>
		</div>
		<div class="title-quantity-popup">
			<h5><a href="/cart">Giỏ hàng của bạn</a></h5>
		</div>
		<div class="content-popup-cart">
			<div class="thead-popup">
				<div style="width: 52%;" class="text-left text-left-xs">Sản phẩm</div>
				<div style="width: 15%;" class="text-right">Đơn giá</div>
				<div style="width: 15%;position: relative;" class="text-right text-center-xs">Số lượng</div>
				<div style="width: 15%;" class="text-right text-right-xs2">Thành tiền</div>
			</div>
			<div class="tbody-popup">
			</div>
			<div class="tfoot-popup">
				<div class="tfoot-popup-1 clearfix">
					<div class="pull-left popup-ship">
						<i class="fa fa-truck" aria-hidden="true"></i>
						<p>Miễn phí giao hàng toàn quốc</p>
						<a class="button btn-continue" title="Tiếp tục mua hàng" onclick="$.fancybox.close();">
							<i class="fa fa-caret-left" aria-hidden="true"></i> Tiếp tục mua hàng
						</a>
					</div>
					<div class="pull-right popup-total">
						<b style="font-size:15px; font-weight: 400;">Phí vận chuyển:</b> <span class="payment-none" style=" color: #de0031;">Tính lúc thanh toán</span>
						<p style="font-weight: 400;">Tổng tiền: <span class="total-price"></span></p>
					</div>
				</div>
				<div class="tfoot-popup-2 clearfix">
					<a class="button btn-checkout" title="Tiến hành đặt hàng" href="/checkout">
						<img class="image_cart_popup" src="//bizweb.dktcdn.net/100/183/542/themes/548520/assets/cart_details.png?1542697260528" />
						<span>Tiến hành đặt hàng </span>
					</a>
					
				</div>
			</div>
		</div>
	</div>
</div>
<div id="myModal" class="modal fade" role="dialog">
</div>
	
		
	
	 
	<script>
		jQuery.browser = {};
		(function () {
			jQuery.browser.msie = false;
			jQuery.browser.version = 0;
			if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
				jQuery.browser.msie = true;
				jQuery.browser.version = RegExp.$1;
			}
		})();
	</script>
	<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/jquery.tooltip.min.js?1542697260528' type='text/javascript'></script>
	<link href='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/popup_cart_desktop.css?1542697260528' rel='stylesheet' type='text/css' />
	<link href='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/bootstrap.min.css?1542697260528' rel='stylesheet' type='text/css' />
<link href='//cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css' rel='stylesheet' type='text/css' />
<link href='//cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css' rel='stylesheet' type='text/css' />




<link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Open+Sans:400,700|Roboto" rel="stylesheet">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/jgrowl.css?1542697260528' rel='stylesheet' type='text/css' />

<link href='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/style.css?1542697260528' rel='stylesheet' type='text/css' />

	

	<script>var ProductReviewsAppUtil=ProductReviewsAppUtil || {};</script>
<link href='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/tkn-style.css?1542697260528' rel='stylesheet' type='text/css' />
<link href='https://instantsearch.bizwebapps.vn/content/font-awesome/css/font-awesome.min.css' rel='stylesheet'>
<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/tkn-util.js?1542697260528' type='text/javascript'></script>
<link href='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/appbulk-blog-statistics.css?1542697260528' rel='stylesheet' type='text/css' />
<link href='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/appbulk-product-statistics.css?1542697260528' rel='stylesheet' type='text/css' />
</head>
<body id="404-khong-tim-thay-trang home" class="  cms-index-index cms-home-page" >  
	<div id="OpacityPage"></div>
<div id="menu-mobile-display"  class="menu-mobile hidden-lg-up">
	<div class="content-menu">
		<div class="title-menu-mobile">
			<a href="/">Mac Cafe</a>
			<div class="sign-mobile">
				
				<span>
					<i class="fa fa-sign-in" aria-hidden="true"></i>
					<a href='/account/login' id='customer_login_link'>Đăng nhập</a>
				</span>
				<br>
				<span>
					<i class="fa fa-user" aria-hidden="true"></i>
					<a href='/account/register' id='customer_register_link'>Tạo tài khoản</a>
				</span>
				
			</div>
		</div>
		<div class="ft-menu-mobile">
			<ul>
				
				<li class="level0 level-top parent"><a href="/"><img class="icon-home" src="https://bizweb.dktcdn.net/100/183/542/themes/548520/assets/home_icon.gif?1500427639693"/></a></li>
				
				<li class="level0 level-top parent"><a href="/macbook-moi">Macbook Mới</a></li>
				
				<li class="level0 level-top parent"><a href="/macbook-cu">Macbook Cũ</a></li>
				
				<li class="level0 level-top parent"><a href="/surface">Surface</a></li>
				
				<li class="level0 level-top parent"><a href="/apple-watch">Apple Watch</a></li>
				
				<li class="level0 level-top parent"><a href="/phu-kien-apple">Phụ kiện Apple</a></li>
				
				<li class="level0 level-top parent"><a href="/audio">Audio</a></li>
				
				<li class="level0 level-top parent"><a href="/service">Sửa chữa</a></li>
				
			</ul>
		</div>
		<div class="navigation">
			<ul id="Mobile_menu" class="topnavmobile">
				<!-- link collection -->
				
				
				<li class="level0 level-top parent"><a href="/collections/all">Tất cả sản phẩm</a></li>
				
				
				
				<li class="level0 level-top parent"><a href="/frontpage">Sản phẩm mới</a></li>
				
				
				
				<li class="level0 level-top parent"><a href="/san-pham-noi-bat">Sản phẩm nổi bật</a></li>
				
				
				
				<li class="level0 level-top parent"><a href="/san-pham-khuyen-mai">Sản phẩm khuyến mãi</a></li>
				
				
			</ul>
		</div>
		<div class="ft-menu-mobile">
			<ul>
				<li><span>Hotline <h6>0968.555.333</h6></span><img src="//bizweb.dktcdn.net/100/183/542/themes/548520/assets/phone-menu-mobile.png?1542697260528" alt="Gọi ngay"/></li>
				
				<li><a href='/'><img class="icon-home" src="https://bizweb.dktcdn.net/100/183/542/themes/548520/assets/home_icon.gif?1500427639693"/></a></li>
				
				<li><a href='/macbook-moi'>Macbook Mới</a></li>
				
				<li><a href='/macbook-cu'>Macbook Cũ</a></li>
				
				<li><a href='/surface'>Surface</a></li>
				
				<li><a href='/apple-watch'>Apple Watch</a></li>
				
				<li><a href='/phu-kien-apple'>Phụ kiện Apple</a></li>
				
				<li><a href='/audio'>Audio</a></li>
				
				<li><a href='/service'>Sửa chữa</a></li>
				
			</ul>
		</div>
	</div>
	<div class="button-close">
		<div id="close-menu" class="btn-close">
			<i class="fa fa-bars" aria-hidden="true"></i>
		</div>
	</div>
</div>
<header>
	
	<div class="header-container">
		<div class="container container_main">
			<div class="row">
				<div class="col-sm-2 col-xs-3 navbar-mobile nav_mx991 hidden-lg-up">
					<a id="showmenu-mobile" class="button-menu">
						<i class="fa fa-bars" aria-hidden="true"></i>
					</a>
				</div>
				<div class="col-lg-3 col-md-8 col-sm-6 col-xs-6 logo_mx991">
					<div class="logo">
						<a href="/" title="Mac Cafe">
							<img src="//bizweb.dktcdn.net/100/183/542/themes/548520/assets/logo.png?1542697260528" alt="Mac Cafe">
						</a>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 hidden-md-down search-item">
					<div class="support_search hidden-md-down">
						
						<h5>Tư vấn mua hàng : </h5><span> 024.38855666</span>&nbsp;&nbsp;|&nbsp;&nbsp;
						
						
						<h5>Hotline : </h5><span> 0968.555.333</span>	
						
					</div>
					<div class="search_form">
						<form action="/search" method="get" class="search-form" role="search">
							<input placeholder="Nhập từ khóa cần tìm..." class="search_input" maxlength="70" id="search" type="text" name="query" value="">
							<input type="submit" value="Tìm kiếm" class="btnsearch">
						</form>
					</div>			
				</div>
				<div class="col-lg-3 col-md-4 col-sm-4 col-xs-3 hidden-xs account-cart">
					<div class="col-lg-8 col-md-7 col-sm-8 hidden-md-down account">
						<div>
							<img class="mg_bt_10" src="//bizweb.dktcdn.net/100/183/542/themes/548520/assets/account.png?1542697260528" alt="Đăng ký hoặc đăng nhập" height="30" width="30">	
						</div>
						<div>
							<span>
								
								<a class="cl_old"><a href='/account/login' id='customer_login_link'>Đăng nhập</a></a>
								/
								<a class="cl_old"><a href='/account/register' id='customer_register_link'>Đăng ký</a></a>
								
							</span>	
						</div>	
					</div>
					<div class="col-lg-4 col-md-5 col-sm-6 col-xs-12 cart cart_mx991">
						<div class="top-cart-contain">
							<div class="mini-cart">
								<div data-toggle="dropdown" data-hover="dropdown" class="basket dropdown-toggle">
									<a>
										<div>
											<a onclick="window.location.href='/cart'"><img class="mg_bt_10" src="//bizweb.dktcdn.net/100/183/542/themes/548520/assets/cart.png?1542697260528" alt="Giỏ hàng" width="30" height="30" /></a>
										</div>
										<div class="cart-box">
											<span class="title cl_old hidden-sm-down">Giỏ hàng</span>
											<span id="cart-total" class="cartCount">0</span>
										</div>
									</a>
								</div>
								<div>
									<div class="top-cart-content arrow_box hidden-md-down">
										<!--<div class="block-subtitle">Sản phẩm đã cho vào giỏ hàng</div>-->
										<ul id="cart-sidebar" class="mini-products-list count_li">
											<li class="list-item">
												<ul></ul>
											</li>
											<li id="footer_cart_item" class="action">
												<ul>
													<li class="li-fix-1">
														<div class="top-subtotal1">
															Phí vận chuyển: 
															<span class="price2">Tính khi thanh toán</span>
														</div>
														<div class="top-subtotal">
															Tổng tiền thanh toán: 
															<span class="price"></span>
														</div>
													</li>
													<li class="li-fix-2" style="">
														<div class="actions">

															<a href="/cart" class="view-cart">
																<span>Giỏ hàng</span>
															</a>
															<a href="/checkout" class="btn-checkout">
																<span>Thanh toán</span>
															</a>
														</div>
													</li>
												</ul>
											</li>
										</ul>
										<script>
											var count = $("ul.count_li > li.item").length;
										</script>
									</div>
								</div>
							</div>
						</div>
					</div>	
				</div>
				<div class="col-md-12 col-sm-12 col-xs-12 search_form_mobile hidden-lg-up">
					<form action="/search" method="get" class="search-form" role="search">
						<input placeholder="Nhập từ khóa cần tìm..." class="search_input_mobile" maxlength="70" id="search" type="text" name="query" value="">
						<button class="submit_button"><i class="btnsearch_mobile fa fa-search" aria-hidden="true"></i></button>
					</form>
				</div>		
			</div>					
		</div>

	</div>
</header>
<nav class="hidden-md-down">
	<div class="container">
		<div class="row nav_menu">
			<div class="col-lg-9 col-md-9 hidden-md-down main-nav">
				<ul id="nav">
					
					<li class=" first  parrent ">
						<a href="/"><img class="icon-home" src="https://bizweb.dktcdn.net/100/183/542/themes/548520/assets/home_icon.gif?1500427639693"/></a>
						
					</li>
					
					<li class=" parrent ">
						<a href="/macbook-moi">Macbook Mới</a>
						
						<ul>
							
							<li>
								<a href="/new-macbook-pro-2018">New Macbook Pro</a>
								
							</li>
							
							<li>
								<a href="/macbook-air">New Macbook Air</a>
								
							</li>
							
							<li>
								<a href="/the-new-macbook-12">New Macbook 12"</a>
								
							</li>
							
						</ul>
						
					</li>
					
					<li class=" parrent ">
						<a href="/macbook-cu">Macbook Cũ</a>
						
						<ul>
							
							<li>
								<a href="/the-new-macbook-12-cu">The New Macbook 12"</a>
								
							</li>
							
							<li>
								<a href="/macbook-pro-cu">Macbook Pro</a>
								
								<ul>
									
									<li>
										<a href="/macbook-touch-bar">Macbook Touch Bar</a>
									</li>
									
									<li>
										<a href="/macbook-non-touch-bar">Macbook non Touch Bar</a>
									</li>
									
									<li>
										<a href="/macbook-retina">Macbook Retina</a>
									</li>
									
								</ul>
								
							</li>
							
							<li>
								<a href="/macbook-air-cu">Macbook Air</a>
								
								<ul>
									
									<li>
										<a href="/macbook-air-13">Macbook Air 13.3"</a>
									</li>
									
									<li>
										<a href="/macbook-air-11">Macbook Air 11.6"</a>
									</li>
									
								</ul>
								
							</li>
							
							<li>
								<a href="/macbook-cu-imac-cinema">iMac/ Cinema</a>
								
							</li>
							
							<li>
								<a href="/macbook-cu-mac-mini">Mac Mini</a>
								
							</li>
							
						</ul>
						
					</li>
					
					<li class=" parrent ">
						<a href="/surface">Surface</a>
						
					</li>
					
					<li class=" parrent ">
						<a href="/apple-watch">Apple Watch</a>
						
						<ul>
							
							<li>
								<a href="/apple-watch-sport">Apple Watch Sport</a>
								
							</li>
							
							<li>
								<a href="/apple-watch-steel">Apple Watch Steel</a>
								
							</li>
							
							<li>
								<a href="/pebble-time-steel">Apple Watch Edition</a>
								
							</li>
							
						</ul>
						
					</li>
					
					<li class=" parrent ">
						<a href="/phu-kien-apple">Phụ kiện Apple</a>
						
						<ul>
							
							<li>
								<a href="/phu-kien-mac">Phụ kiện Mac</a>
								
								<ul>
									
									<li>
										<a href="/balo-tui-xach">Balo & Túi xách</a>
									</li>
									
									<li>
										<a href="/tui-chong-shock">Túi chống shock</a>
									</li>
									
									<li>
										<a href="/airport-wireless">Airport & Wireless</a>
									</li>
									
									<li>
										<a href="/keyboard-mouse-hub">Keyboard, Mouse & Hub</a>
									</li>
									
									<li>
										<a href="/sac-cable">Sạc & Cable</a>
									</li>
									
									<li>
										<a href="/dan-bao-ve">Dán bảo vệ</a>
									</li>
									
									<li>
										<a href="/de-tan-nhiet-stand">Đế tản nhiệt, Stand</a>
									</li>
									
								</ul>
								
							</li>
							
							<li>
								<a href="/phu-kien-apple-watch">Phụ kiện Apple Watch</a>
								
								<ul>
									
									<li>
										<a href="/dock-sac">Dock sạc</a>
									</li>
									
									<li>
										<a href="/day-deo">Dây đeo</a>
									</li>
									
									<li>
										<a href="/dan-bao-ve-1">Dán bảo vệ</a>
									</li>
									
								</ul>
								
							</li>
							
							<li>
								<a href="/phu-kien-airpods">Phụ kiện Airpods</a>
								
							</li>
							
							<li>
								<a href="/phu-kien-anker">Phụ kiện Anker</a>
								
								<ul>
									
									<li>
										<a href="/pin-sac-anker">Sạc Anker</a>
									</li>
									
									<li>
										<a href="/cap-sac-anker">Cáp Anker</a>
									</li>
									
									<li>
										<a href="/sac-du-phong-anker">Sạc dự phòng Anker</a>
									</li>
									
									<li>
										<a href="/tai-nghe-loa-anker">Tai nghe, Loa Anker</a>
									</li>
									
								</ul>
								
							</li>
							
							<li>
								<a href="/phu-kien-iphone-ipad">Phụ kiện iPhone/iPad</a>
								
								<ul>
									
									<li>
										<a href="/iphone-case">iPhone case</a>
									</li>
									
									<li>
										<a href="/ipad-case">iPad Case</a>
									</li>
									
									<li>
										<a href="/ipod-case">Dán cường lực</a>
									</li>
									
									<li>
										<a href="/tai-nghe-sac-cable">Tai nghe, Sạc, Cable</a>
									</li>
									
									<li>
										<a href="/but-cam-ung">Bút cảm ứng</a>
									</li>
									
									<li>
										<a href="/dock">Dock</a>
									</li>
									
									<li>
										<a href="/gamepad">GamePad</a>
									</li>
									
								</ul>
								
							</li>
							
							<li>
								<a href="/phu-kien-xe-hoi">Phụ kiện xe hơi</a>
								
							</li>
							
							<li>
								<a href="/pin-sac-du-phong-1">Pin sạc dự phòng</a>
								
							</li>
							
						</ul>
						
					</li>
					
					<li class=" parrent ">
						<a href="/audio">Audio</a>
						
						<ul>
							
							<li>
								<a href="/tai-nghe">Tai nghe</a>
								
							</li>
							
							<li>
								<a href="/loa">Loa</a>
								
							</li>
							
						</ul>
						
					</li>
					
					<li class=" last  parrent ">
						<a href="/service">Sửa chữa</a>
						
						<ul>
							
							<li>
								<a href="/pin-apple">Thay Pin</a>
								
							</li>
							
							<li>
								<a href="/thay-loa">Thay Loa</a>
								
							</li>
							
							<li>
								<a href="/lcd-mat-kinh">LCD/ Mặt kính</a>
								
							</li>
							
							<li>
								<a href="/thay-ban-phim">Thay bàn phím</a>
								
							</li>
							
							<li>
								<a href="/thay-wifi-macbook">Thay Card WiFi</a>
								
							</li>
							
							<li>
								<a href="/cac-dich-vu-khac">Các dịch vụ khác</a>
								
							</li>
							
						</ul>
						
					</li>
					
				</ul>
			</div>
			<div class="col-lg-3 col-md-3 hidden-sm-down social pull-right hidden-xs ">
				
				
				<div class="social-icon"><a href="#" title ="Theo dõi Mac Cafe trên Youtube"><i class="fa fa-youtube" aria-hidden="true"></i></a></div>
				
				
				
				
				<div class="social-icon"><a href="https://www.facebook.com/maccafe.vn/" title ="Theo dõi Mac Cafe trên Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></div>
				
			</div>
		</div>

	</div>
</nav>



	<h1 style="display:none;">Mac Cafe </h1>
<div class="content-page">
	<div class="page-content">
		
		<div class="brd">
  <div class="container">
    <div class="row">
      <div class="inner">
        <ul class="breadcrumbs">
          <li class="home"> <a title="Quay lại trang chủ" href="/">Trang chủ</a></li>
           
			<i class="fa fa-angle-right" aria-hidden="true"></i>
			<li><span>Trang lỗi - Không có nội dung</span></li>
			
			
        </ul>
      </div>
    </div>
  </div>
</div>	

		<section class="main-contact">
			<div class="container">
				<div class="page_content_">
					<div class="" style="text-align:center;">
					<h1 class="error_page">404</h1>
					<span class="text_error">Trang này không có dữ liệu hoặc đã bị quản trị viên xoá vui lòng click vào <a href="/" style="color:#de0031">đây</a> để quay lại trang chủ</span>
					</div>
				</div>
			</div>
		</section>
		
	</div>
</div>
	
	
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TGTQNMQ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->



	<link href='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/bpr-products-module.css?1542697260528' rel='stylesheet' type='text/css' />
<div class="bizweb-product-reviews-module"></div>
	
<link href='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/is-keywords-module.css?1542697260528' rel='stylesheet' type='text/css' />
<div class="is-keywords-module"></div>
<footer id="footer" class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="footer">
		<div class="container">
			<section class="footer-up hidden-xs-down">
				<div class="row">
					<div class="col-lg-3 col-md-6 col-sm-4 col-xs-12 hidden-sm-down footer-vertical">
						<h5>Thông tin công ty</h5>
						
						<li><a href='/'>Trang chủ</a></li>
						
						<li><a href='/collections/all'>Sản phẩm</a></li>
						
						<li><a href='/blogs/all'>Tin tức</a></li>
						
						<li><a href='/lien-he'>Liên hệ</a></li>
						

					</div>
					<div class="col-lg-3 col-md-6 col-sm-4 col-xs-12 hidden-sm-down footer-vertical">
						<h5>Hỗ trợ khách hàng</h5>
						
						<li><a href='/huong-dan'>Hướng dẫn mua hàng</a></li>
						
						<li><a href='/huong-dan'>Giao nhận và thanh toán</a></li>
						
						<li><a href='/huong-dan'>Đổi trả và bảo hành</a></li>
						
						<li><a href='/huong-dan'>Đăng ký thành viên</a></li>
						

					</div>
					<div class="col-lg-3 col-md-6 col-sm-4 col-xs-12 hidden-sm-down footer-vertical">
						<h5>Chính sách mua hàng</h5>
						
						<li><a href='/chinh-sach'>Chính sách thanh toán</a></li>
						
						<li><a href='/chinh-sach'>Chính sách vận chuyển</a></li>
						
						<li><a href='/chinh-sach'>Chính sách đổi trả</a></li>
						
						<li><a href='/chinh-sach'>Chính sách bảo hành</a></li>
						

					</div>
					<div class="col-lg-3 col-md-6 col-sm-4 col-xs-12 hidden-sm-down footer-vertical facebook-widget">
						
						<div id="fb-root"></div>
						<script>(function(d, s, id) {
							var js, fjs = d.getElementsByTagName(s)[0];
							if (d.getElementById(id)) return;
							js = d.createElement(s); js.id = id;
							js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7&appId=631942543575730";
							fjs.parentNode.insertBefore(js, fjs);
							}(document, 'script', 'facebook-jssdk'));
						</script>
						<div class="fb-page" data-href="https://www.facebook.com/maccafevn/" data-tabs="timeline" data-height="170" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
							<blockquote cite="https://www.facebook.com/maccafevn/" class="fb-xfbml-parse-ignore">
								<a href="https://www.facebook.com/maccafevn/">Facebook</a>
							</blockquote>
						</div>
					</div>
				</div>
			</section>


			<section class="footer-up">
				<div class="col-xs-12 hidden-sm-up">
					<div id="toogle_click" class="widget-item panel">
						<h5 class="widget-title" data-toggle="collapse" data-parent="#accordion" >Thông tin công ty<i class="fa fa-angle-down " aria-hidden="true"></i></h5>
						<ul class="widget-menu panel-collapse collapse in" id="collapseOne">

							
							<li><a href='/'>Trang chủ</a></li>
							
							<li><a href='/collections/all'>Sản phẩm</a></li>
							
							<li><a href='/blogs/all'>Tin tức</a></li>
							
							<li><a href='/lien-he'>Liên hệ</a></li>
							

						</ul>
					</div>
				</div>


				<div class="col-xs-12 hidden-sm-up">
					<div id="toogle_click" class="widget-item panel">
						<h5 class="widget-title" data-toggle="collapse" data-parent="#accordion" >Hỗ trợ khách hàng<i class="fa fa-angle-right " aria-hidden="true"></i></h5>
						<ul class="widget-menu panel-collapse collapse" id="collapseTwo">

							
							<li><a href='/huong-dan'>Hướng dẫn mua hàng</a></li>
							
							<li><a href='/huong-dan'>Giao nhận và thanh toán</a></li>
							
							<li><a href='/huong-dan'>Đổi trả và bảo hành</a></li>
							
							<li><a href='/huong-dan'>Đăng ký thành viên</a></li>
							

						</ul>
					</div>
				</div>


				<div class="col-xs-12 hidden-sm-up">
					<div id="toogle_click" class="widget-item panel">
						<h5 class="widget-title" data-toggle="collapse" data-parent="#accordion" >Chính sách mua hàng<i class="fa fa-angle-right " aria-hidden="true"></i></h5>
						<ul class="widget-menu panel-collapse collapse" id="collapseThree">

							
							<li><a href='/chinh-sach'>Chính sách thanh toán</a></li>
							
							<li><a href='/chinh-sach'>Chính sách vận chuyển</a></li>
							
							<li><a href='/chinh-sach'>Chính sách đổi trả</a></li>
							
							<li><a href='/chinh-sach'>Chính sách bảo hành</a></li>
							

						</ul>
					</div>
				</div>

				<div class="col-lg-3 col-md-6 col-sm-4 col-xs-12 hidden-sm-up footer-vertical facebook-widget">
					<div class="fb-page fb_iframe_widget" data-href="https://www.facebook.com/bizwebvietnam/" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="true" fb-xfbml-state="rendered" fb-iframe-plugin-query="adapt_container_width=true&amp;app_id=&amp;container_width=263&amp;hide_cover=true&amp;href=https%3A%2F%2Fwww.facebook.com%2Fbizwebvietnam%2F&amp;locale=vi_VN&amp;sdk=joey&amp;show_facepile=true&amp;small_header=true"><span style="vertical-align: bottom; width: 263px; height: 170px;"><iframe name="f1c0a2a66ef83f4" width="1000px" height="1000px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" title="fb:page Facebook Social Plugin" src="https://www.facebook.com/v2.6/plugins/page.php?adapt_container_width=true&amp;app_id=&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2FuN4_cXtJDGb.js%3Fversion%3D42%23cb%3Df5799d1c5eb998%26domain%3Dbigmart-1.bizwebvietnam.net%26origin%3Dhttps%253A%252F%252Fbigmart-1.bizwebvietnam.net%252Ff16570c8870773c%26relation%3Dparent.parent&amp;container_width=263&amp;hide_cover=true&amp;href=https%3A%2F%2Fwww.facebook.com%2Fbizwebvietnam%2F&amp;locale=vi_VN&amp;sdk=joey&amp;show_facepile=true&amp;small_header=true" style="border: none; visibility: visible; width: 263px; height: 170px;" class=""></iframe></span></div>
				</div>

			</section>
			

			
			<section class="footer-bottom-1 hidden-md-down">
				<div class="row">
					<div class="title-bottom">
						<h5>Công ty TNHH Mac Cafe Việt Nam</h5>
					</div>
					<div class="col-lg-6 col-md-6">
						<div class="txt-bottom">
							<p>Địa chỉ: Số 46B Quán Sứ, Hoàn Kiếm, Hà Nội</p>
							<p>Điện thoại: 04.38855666 - HOTLINE: 0968.555.333</p>
						</div>

					</div>

					<div class="col-lg-6 col-md-6">
						<div class="txt-bottom">
							<p>Copyright © 2017 Mac-cafe.vn . All rights reserved</p>
							<p>Một sản phẩm được xây dựng & tư vấn bởi Hiển Nguyễn</p>
						</div>

					</div>
				</div>
			</section>
			

		</div>
	</div>
	<div class="ft-bottom">
		<div class="container ft">
			<div class="row">
				<div class="col-lg-12 col-xs-12 copyright">
					<p>© Bản quyền thuộc về <b style="color:#fff;">Mac Cafe</b> <b class="line-down"><span class="hidden-xs-down">|</span> Cung cấp bởi <span><a href="https://www.bizweb.vn/?utm_source=site-khach-hang&utm_campaign=referral_bizweb&utm_medium=footer&utm_content=cung-cap-boi-bizweb" target="_blank" title="Bizweb">&nbsp;Bizweb</a></span></b></p>
				</div>
			</div>
		</div>
	</div>
</footer>
	<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/option-selectors.js?1542697260528' type='text/javascript'></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/tether/1.3.1/js/tether.min.js"></script>


	<script src='//bizweb.dktcdn.net/assets/themes_support/api.jquery.js?4' type='text/javascript'></script> 
	


<div id="quick-view-product" style="display:none;">
		<div id="overlay" class="overlay no-background" style="background: rgba(0, 0, 0, 0.619608);overflow: hidden; width: 100%; height: 100%;cursor: pointer;"></div>

	<div class="quick-view-product" ></div>
	<div id="quickview-modal" style="display:none;">
		<div class="row product_info">


			<div class="col-lg-5 col-md-5 col-sm-6 col-xs-12 ">
				<div class="clearfix image-block block_quickview_img">
					<span class="view_full_size">
						<a class="img-product" title="" href="#">
							<img id="product-featured-image-quickview" class="img-responsive product-featured-image-quickview" src="//bizweb.dktcdn.net/100/183/542/themes/548520/assets/noimage.png?1542697260528" alt="Mac Cafe"  />
						</a>
					</span>
					<div class="loading-imgquickview" style="display:none;"></div>
				</div>
				<div class="more-view-wrapper clearfix">
					<div id="thumbs_list_quickview">
						<ul class="product-photo-thumbs quickview-more-views-owlslider" id="thumblist_quickview"></ul>
					</div>
				</div>

			</div>
			<div class="col-lg-7 col-md-7 col-sm-6 col-xs-12 content_prd">
				<div class="product_infomation">
					<div class="product_title">
						<h3 class="fw_600 qwp-name">&nbsp;</h3>
					</div>
					<div class="product_vendor clc5">
						<p class="cl_mobile_old">Thương hiệu  <span>:&nbsp;<span class="cl_main vendor brand"></span> <span class="hidden-sm-down tags_name"> </span></span></p>
					</div>
					<div class="reviews">
						<p class="cl_mobile_old hidden-sm-up">Đánh giá </p> <span class=" vendor_text hidden-sm-up">:</span>
						<div class="danhgiasao">
							<div class="bizweb-product-reviews-badge" data-id=""></div>

						</div>
					</div>
					<div class="product_price">
						<div class="price-block">
							<div class="price-box">
								<p class="special-price giamoi"><span class="price"></span></p>
								<p class="old-price giasosanh" id="old-price"><span class="price"></span></p>
							</div>
							<div class="sale_label hidden-xs-down on_sale">
								<span class="price_sale"></span>
							</div>
						</div>
					</div>
					<div class="product_content hidden-sm-down">
						<h5 class="fw_600">Mô tả :</h5>
						<div class="cl_old product-description rte"><span class="ct_pr"></span><span class="more_link"></span></div>
					</div>
				</div>

				<div class="product_pre_buy">
					<div class="add-to-box">
						<div class="add-to-cart">
							<form action="/cart/add" method="post" enctype="multipart/form-data" class="variants form-ajaxtocart">
								<span class="price-product-detail" style="opacity: 0;">
									<span class="special-price old-price product-price compare-price"></span>
								</span>
								<select name='variantId' style="display:none"></select>
								<div class="clearfix"></div>
								<div class="quantity_wanted_p">
									<label for="quantity-detail" class="soluong cl_old cl_mobile_old quantity-selector">Số lượng</label>
									<input type="number" id="quantity-detail" name="quantity" value="1" min="1" onkeyup="valid(this,'numbers')" onblur="valid(this,'numbers')" class="prd_quantity quantity-selector text-center">
									<button type="submit" name="add" class="btn_muahang btn_buy_product btn_muangay_list btn add_to_cart_detail ajax_addtocart">
										<span class="text_buy"> Mua ngay</span>
									</button>
								</div>

							</form>
						</div>
					</div>
				</div>

			</div>


		</div>





		<a title="Close" class="quickview-close close-window" href="javascript:;"><i class="fa  fa-close"></i></a>
	</div>
</div>



<script type="text/javascript">  
	 function valid(o,w){
		 o.value = o.value.replace(valid.r[w],'');
		 var qtyCount = document.getElementById('quantity-detail').value;
		 if(qtyCount == 0){
			 document.getElementById("quantity-detail").value = 1;
		 }
        }
        valid.r={
			'numbers':/[^\d]/g
        }
		
	Bizweb.doNotTriggerClickOnThumb = false;
	function changeImageQuickView(img, selector) {
		var src = $(img).attr("src");
		src = src.replace("_compact", "");
		$(selector).attr("src", src);
	}
	var selectCallbackQuickView = function(variant, selector) {
		var productItem = jQuery('.quick-view-product .product_info');
		var addToCart = productItem.find('.add_to_cart_detail'),
			sale_label = productItem.find('.sale_label .price_sale'),
			textbuy = productItem.find('.text_buy'),
			 giamgia = Math.round(100*(variant.compare_at_price - variant.price)/variant.compare_at_price),
			saleoff = productItem.find('.sale_label .price_sale'),
			bg_sale = jQuery('.on_sale'),
			price = productItem.find('.price-box .special-price .price'),
			priceSale = productItem.find('.price-box .old-price .price'),
			button_buy = productItem.find('.btn_muahang'),
			totalPrice = productItem.find('.total-price span');

			
		
			if (variant) {
				if (variant.inventory_management == "bizweb" && variant.inventory_policy != "continue") {
					if (variant.inventory_quantity > 0 && variant.price != '0') {
						if (variant.inventory_quantity <= 100) {
							 if (variant.compare_at_price > variant.price) {
								textbuy.html('Mua hàng');
								button_buy.addClass('ajax_addtocart');
								 saleoff.html('-'+ giamgia +'%').css("color", "#fff");
								 bg_sale.css("display", "block");
								button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
								price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫")).css("color", "#de0031");
								 priceSale.html(Bizweb.formatMoney(variant.compare_at_price, "{{amount_no_decimals_with_comma_separator}}₫")).show();    
								jQuery('#variant-inventory').text('Cửa hàng hiện có ' + variant.inventory_quantity + ' sản phẩm. Co khuyến mại, số lượng còn trong kho');

							 } else {
								 textbuy.html('Mua hàng');
								button_buy.addClass('ajax_addtocart');
								 price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫")).css("color", "#de0031");
								 priceSale.css("display", "none");
								bg_sale.css("display", "none");
								button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
								jQuery('#variant-inventory').text('Cửa hàng hiện có ' + variant.inventory_quantity + ' sản phẩm. không khuyến mại, còn trong kho');
							 }

						}else {
							textbuy.html('Liên hệ');
							button_buy.addClass('disabled').attr('disabled', 'disabled');
							bg_sale.css("display", "none");
							price.css("display", "none");
							 priceSale.css("display", "none");
							button_buy.removeClass('ajax_addtocart');
							jQuery('#variant-inventory').text("Cửa hàng đã hết loại này");
						}
					} else if (variant.inventory_quantity > 0 && variant.price == 0){
						textbuy.html('Liên hệ');
						button_buy.addClass('disabled').attr('disabled', 'disabled');
						button_buy.removeClass('ajax_addtocart');
						bg_sale.css("display", "none");
						price.css("display", "none");
						priceSale.css("display", "none");
						jQuery('#variant-inventory').text('Còn hàng đấy Gọi điện đi - đặt giá 0đ + trong kho còn ' + variant.inventory_quantity + ' sản phẩm');
					}else {
						bg_sale.css("display", "none");
						price.css("display", "none");
						priceSale.css("display", "none");
						textbuy.html('Hết hàng');
						addToCart.addClass('disabled').attr('disabled', 'disabled');
						jQuery('#variant-inventory').text("Chua ro");
					}
				}else if (variant.inventory_management == null && variant.price < 1 ) {
					textbuy.html('Hết hàng');
					button_buy.addClass('disabled').attr('disabled', 'disabled');
					bg_sale.css("display", "none");
					price.css("display", "none");
					priceSale.css("display", "none");
					jQuery('#variant-inventory').text("Hết hàng");
				}else if (variant.inventory_management == null && variant.compare_at_price > variant.price  ) {
					textbuy.html('Mua hàng');
					bg_sale.css("display", "block");
					saleoff.html('-'+ giamgia +'%').css("color", "#fff");
					price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫")).css("color", "#de0031");
					priceSale.html(Bizweb.formatMoney(variant.compare_at_price, "{{amount_no_decimals_with_comma_separator}}₫")).show();  
					button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
					jQuery('#variant-inventory').text("Hàng có sẵn quản lý kho có khuyến mãi");
				}else if (variant.inventory_management != null && variant.compare_at_price > variant.price  ) {
					textbuy.html('Mua hàng');
					price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫")).css("color", "#de0031");
					priceSale.html(Bizweb.formatMoney(variant.compare_at_price, "{{amount_no_decimals_with_comma_separator}}₫")).show();  
					saleoff.html('-'+ giamgia +'%').css("color", "#fff");
					bg_sale.css("display", "block");
					button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
					jQuery('#variant-inventory').text("Hàng có sẵn không quản lý kho có khuyến mãi");
				} else if (variant.inventory_management == null && variant.price != 0 ) {
					 if (variant.compare_at_price > variant.price) {
						 textbuy.html('Mua hàng');
						price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫")).css("color", "#de0031");
						priceSale.html(Bizweb.formatMoney(variant.compare_at_price, "{{amount_no_decimals_with_comma_separator}}₫")).show();  
						saleoff.html('-'+ giamgia +'%').css("color", "#fff");
						 bg_sale.css("display", "block");
						 button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
						 jQuery('#variant-inventory').text('Cửa hàng không quản lý kho. Co khuyến mại');
					 } else if (variant.compare_at_price < variant.price){
						price.css("display", "none");
						priceSale.css("display", "none");
						textbuy.html('Liên hệ');
						button_buy.addClass('disabled').attr('disabled', 'disabled');
						bg_sale.css("display", "none");
					jQuery('#variant-inventory').text("Cửa hàng không quản lý kho, giá gốc lớn hơn giá khuyến mại");
					 } 
					else {
						 textbuy.html('Mua hàng');
						 price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫")).css("color", "#de0031");
						priceSale.css("display", "none");
						bg_sale.css("display", "none");
						 button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
						 jQuery('#variant-inventory').text('Cửa hàng không quản lý kho. không khuyến mại - giá đúng');
					 }
				} else if (variant.inventory_management != null && variant.price != 0 ) {
					 if (variant.compare_at_price > variant.price) {
						 textbuy.html('Mua hàng');
						 price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫"));
						priceSale.html(Bizweb.formatMoney(variant.compare_at_price, "{{amount_no_decimals_with_comma_separator}}₫")).show();  
						saleoff.html('-'+ giamgia +'%').css("color", "#fff");
						 bg_sale.css("display", "block");
						 button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
						 jQuery('#variant-inventory').text('Cửa hàng hiện có ' + variant.inventory_quantity + ' sản phẩm. Co khuyến mại có quản lý kho, số lượng chưa xác định');
					 } else if (variant.compare_at_price < variant.price){
						 price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫")).css("color", "#de0031");
						priceSale.css("display", "none");
						bg_sale.css("display", "none");
						textbuy.html('Mua hàng');
						button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
					jQuery('#variant-inventory').text("Hàng có quản lý kho, giá gốc lớn hơn giá khuyến mại");
					 } else {
						 textbuy.html('Mua hàng');
						 price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫")).css("color", "#de0031");
						priceSale.css("display", "none");
						bg_sale.css("display", "none");
						 button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
						 jQuery('#variant-inventory').text('Cửa hàng hiện có ' + variant.inventory_quantity + ' sản phẩm. không khuyến mại, có quản lý kho, số lượng chưa xác định');
					 }

				} else {
					textbuy.html('Hết hàng');
					button_buy.htmladdClass('disabled').attr('disabled', 'disabled');
					bg_sale.css("display", "none");
					 price.css("display", "none");
						priceSale.css("display", "none");
					jQuery('#variant-inventory').text("Khôg còn hàng nhé, vì giá đặt 0đ + không quản lý kho");
				}
			} else {
				price.css("display", "none");
				priceSale.css("display", "none");
				bg_sale.css("display", "none");
				textbuy.html('Hết hàng');
				button_buy.addClass('disabled').attr('disabled', 'disabled');
				jQuery('#variant-inventory').text("Chua ro 2");
			}

			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
			var form = jQuery('#' + selector.domIdPrefix).closest('form');
			 for (var i=0,length=variant.options.length; i<length; i++) {
				 var radioButton = form.find('.swatch[data-option-index="' + i + '"] :radio[value="' + variant.options[i] +'"]');
				 if (radioButton.size()) {
					 radioButton.get(0).checked = true;
				 }
			 }
			 
			
			 updatePricingQuickView();
			  
			   /*begin variant image*/
			   if (variant && variant.featured_image != null) {
				   
				   var originalImage = $("#product-featured-image-quickview");
				   var newImage = variant.featured_image;
				   var element = originalImage[0];
				   Bizweb.Image.switchImage(newImage, element, function (newImageSizedSrc, newImage, element) {
					   $('#thumblist_quickview img').each(function() {
						   var parentThumbImg = $(this).parent();
						   var productImage = $(this).parent().data("image");
						   if (newImageSizedSrc.includes(productImage)) {
							   $(this).parent().trigger('click');
							   return false;
						   }
					   });
				   });
				   
				   
				   
				   
			   } else {
				   if (variant.compare_at_price > variant.price) {
						 textbuy.html('Mua hàng');
						 price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫"));
						priceSale.html(Bizweb.formatMoney(variant.compare_at_price, "{{amount_no_decimals_with_comma_separator}}₫")).show();  
						saleoff.html('-'+ giamgia +'%').css("color", "#fff");
						 bg_sale.css("background", "red");
						 button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
						 jQuery('#variant-inventory').text('Cửa hàng hiện có ' + variant.inventory_quantity + ' sản phẩm. Co khuyến mại có quản lý kho, số lượng chưa xác định');
					 } else if (variant.compare_at_price < variant.price){
						 price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫")).css("color", "#de0031");
						priceSale.html(' ');
						bg_sale.css("background", "#fff");
						textbuy.html('Mua hàng');
						button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
					jQuery('#variant-inventory').text("Hàng có quản lý kho, giá gốc lớn hơn giá khuyến mại");
					 } else {
						 textbuy.html('Mua hàng');
						 price.html(Bizweb.formatMoney(variant.price, "{{amount_no_decimals_with_comma_separator}}₫")).css("color", "#de0031");
						priceSale.html(' ');
						bg_sale.css("background", "#fff");
						 button_buy.removeClass('disabled').removeAttr('disabled', 'disabled');
						 jQuery('#variant-inventory').text('Cửa hàng hiện có ' + variant.inventory_quantity + ' sản phẩm. không khuyến mại, có quản lý kho, số lượng chưa xác định');
					 }

			   }
			   
			  };
			jQuery('.swatch :radio').change(function() {
			   var optionIndex = jQuery(this).closest('.swatch').attr('data-option-index');
			   var optionValue = jQuery(this).val();
			   jQuery(this)
				   .closest('form')
				   .find('.single-option-selector')
				   .eq(optionIndex)
				   .val(optionValue)
				   .trigger('change');
		   });
</script> 
	<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/bootstrap.min.js?1542697260528' type='text/javascript'></script>
<script src='//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.js' type='text/javascript'></script>
<link href='//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.css' rel='stylesheet' type='text/css' />
<script src='//cdnjs.cloudflare.com/ajax/libs/flexslider/2.2.0/jquery.flexslider.js' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/quickviews.js?1542697260528' type='text/javascript'></script> 
<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/common.js?1542697260528' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/cloud-zoom.js?1542697260528' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/assets/themes_support/api.jquery.js?4' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/js_custome.js?1542697260528' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/jgrowl.js?1542697260528' type='text/javascript'></script>
<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/ajax_cart.js?1542697260528' type='text/javascript'></script> 
<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/owl.carousel.min.js?1542697260528' type='text/javascript'></script>

	<script>

	Bizweb.updateCartFromForm = function(cart, cart_summary_id, cart_count_id) {
		if ((typeof cart_summary_id) === 'string') {
			var cart_summary = jQuery(cart_summary_id);
			if (cart_summary.length) {
				// Start from scratch.
				cart_summary.empty(); 
				// Pull it all out.        
				jQuery.each(cart, function(key, value) {
					if (key === 'items') {
						var table = jQuery(cart_summary_id);           
						if (value.length) {   
							jQuery('<ul class="list-item-cart"></ul>').appendTo(table);
							jQuery.each(value, function(i, item) {	
								var buttonQty = "";
								if(item.quantity == '1'){
									buttonQty = 'disabled';
								}else{
									buttonQty = '';
								}
								var link_img2 = Bizweb.resizeImage(item.image, 'small');
								if(link_img2=="null" || link_img2 =='' || link_img2 ==null){
									link_img2 = 'https://bizweb.dktcdn.net/thumb/large/assets/themes_support/noimage.gif';
								}
								jQuery('<li class="item productid-' + item.variant_id +'"><a class="product-image" href="' + item.url + '" title="' + item.name + '">'
									   + '<img alt="'+  item.name  + '" src="' + link_img2  +  '"width="'+ '80' +'"\></a>'
									   + '<div class="detail-item"><div class="product-details"> <a href="javascript:;" data-id="'+ item.variant_id +'" title="Xóa" class="remove-item-cart fa fa-trash-o">&nbsp;</a>'
									   + '<p class="product-name"> <a href="' + item.url + '" title="' + item.name + '">' + item.name + '</a></p></div>'
									   + '<div class="product-details-bottom"><span class="price">' + Bizweb.formatMoney(item.price, "{{amount_no_decimals_with_comma_separator}}₫") + '</span>'
									   + '<div class="quantity-select"><input class="variantID" type="hidden" name="variantId" value="'+ item.variant_id +'"><button onClick="var result = document.getElementById(\'qty'+ item.variant_id +'\'); var qty'+ item.variant_id +' = result.value; if( !isNaN( qty'+ item.variant_id +' ) &amp;&amp; qty'+ item.variant_id +' &gt; 1 ) result.value--;return false;" class="reduced items-count btn-minus" ' + buttonQty + ' type="button">–</button><input type="text" maxlength="12" min="0" class="input-text number-sidebar qty'+ item.variant_id +'" id="qty'+ item.variant_id +'" name="Lines" id="updates_'+ item.variant_id +'" size="4" value="'+ item.quantity +'"><button onClick="var result = document.getElementById(\'qty'+ item.variant_id +'\'); var qty'+ item.variant_id +' = result.value; if( !isNaN( qty'+ item.variant_id +' )) result.value++;return false;" class="increase items-count btn-plus" type="button">+</button></div></div></li>').appendTo(table.children('.list-item-cart'));
							}); 
							jQuery('<div><div class="top-subtotal">Tổng cộng: <span class="price">' + Bizweb.formatMoney(cart.total_price, "{{amount_no_decimals_with_comma_separator}}₫") + '</span></div></div>').appendTo(table);
							jQuery('<div><div class="actions"><button class="view-cart btn-style" type="button" onclick="window.location.href=\'/cart\'"><span>Giỏ hàng</span></button><button class="btn-checkout btn-style" type="button" onclick="window.location.href=\'/checkout\'"><span>Thanh toán</span></button></div></div>').appendTo(table);

						}
						else {
							jQuery('<div class="no-item"><p>Không có sản phẩm nào trong giỏ hàng.</p></div>').appendTo(table);

						}
					}
				});
			}
		}
		updateCartDesc(cart);
	}

	Bizweb.updateCartPageForm = function(cart, cart_summary_id, cart_count_id) {
		if ((typeof cart_summary_id) === 'string') {
			var cart_summary = jQuery(cart_summary_id);
			if (cart_summary.length) {
				// Start from scratch.
				cart_summary.empty();
				// Pull it all out.        
				jQuery.each(cart, function(key, value) {
					if (key === 'items') {
						var table = jQuery(cart_summary_id);           
						if (value.length) {  

							var pageCart = '<div class="cart page_cart min768">'
							+ '<form action="/cart" method="post" novalidate><div class="bg-scroll"><div class="cart-thead">'
							+ '<div style="width: 17%">Ảnh sản phẩm</div><div style="width: 33%"><span class="nobr">Tên sản phẩm</span></div><div style="width: 15%" class="a-center"><span class="nobr">Đơn giá</span></div><div style="width: 14%" class="a-center">Số lượng</div><div style="width: 15%" class="a-center">Thành tiền</div><div style="width: 6%">Xoá</div></div>'
							+ '<div class="cart-tbody"></div></div></form></div>'; 
							var pageCartCheckout = '<div class="cart-collaterals cart_submit row"><div class="totals col-sm-6 col-md-5 col-xs-12 col-md-offset-7"><div class="totals"><div class="inner">'
							+ '<table class="table shopping-cart-table-total" id="shopping-cart-totals-table"><colgroup><col><col></colgroup>'
							+ '<tfoot><tr><td colspan="1" class="a-left"><strong>Tổng tiền</strong></td><td class="a-right"><strong><span class="totals_price price">' + Bizweb.formatMoney(cart.total_price, "{{amount_no_decimals_with_comma_separator}}₫") + '</span></strong></td></tr></tfoot></table>'
							+ '<ul class="checkout"><li><button class="button btn-proceed-checkout" title="Tiến hành đặt hàng" type="button" onclick="window.location.href=\'/checkout\'"><span>Tiến hành đặt hàng</span></button></li>'
							+ '</ul></div></div></div></div>';
							jQuery(pageCart).appendTo(table);
							jQuery.each(value, function(i, item) {
								var buttonQty = "";
								if(item.quantity == '1'){
									buttonQty = 'disabled';
								}else{
									buttonQty = '';
								}
								var link_img1 = Bizweb.resizeImage(item.image, 'medium');
								if(link_img1=="null" || link_img1 =='' || link_img1 ==null){
									link_img1 = 'https://bizweb.dktcdn.net/thumb/large/assets/themes_support/noimage.gif';
								}
								var pageCartItem = '<div class="item-cart productid-' + item.variant_id +'"><div style="width: 17%" class="image"><a class="product-image" title="' + item.name + '" href="' + item.url + '"><img width="100" height="auto" alt="' + item.name + '" src="' + link_img1 +  '"></a></div>'
								+ '<div style="width: 33%" class="a-center"><h2 class="product-name"> <a href="' + item.url + '">' + item.title + '</a> </h2><span class="variant-title">' + item.variant_title + '</span></div><div style="width: 15%" class="a-center"><span class="item-price"> <span class="price">' + Bizweb.formatMoney(item.price, "{{amount_no_decimals_with_comma_separator}}₫") + '</span></span></div>'
								+ '<div style="width: 14%" class="a-center"><div class="input_qty_pr"><input class="variantID" type="hidden" name="variantId" value="'+ item.variant_id +'"><button onClick="var result = document.getElementById(\'qtyItem'+ item.variant_id +'\'); var qtyItem'+ item.variant_id +' = result.value; if( !isNaN( qtyItem'+ item.variant_id +' ) &amp;&amp; qtyItem'+ item.variant_id +' &gt; 1 ) result.value--;return false;" ' + buttonQty + ' class="reduced_pop items-count btn-minus" type="button">–</button><input type="text" maxlength="12" min="0" class="input-text number-sidebar input_pop input_pop qtyItem'+ item.variant_id +'" id="qtyItem'+ item.variant_id +'" name="Lines" id="updates_'+ item.variant_id +'" size="4" value="'+ item.quantity +'"><button onClick="var result = document.getElementById(\'qtyItem'+ item.variant_id +'\'); var qtyItem'+ item.variant_id +' = result.value; if( !isNaN( qtyItem'+ item.variant_id +' )) result.value++;return false;" class="increase_pop items-count btn-plus" type="button">+</button></div></div>'
								+ '<div style="width: 15%" class="a-center"><span class="cart-price"> <span class="price">'+ Bizweb.formatMoney(item.price * item.quantity, "{{amount_no_decimals_with_comma_separator}}₫") +'</span> </span></div>'
								+ '<div style="width: 6%"><a class="button remove-item remove-item-cart" title="Xóa" href="javascript:;" data-id="'+ item.variant_id +'"><span><span>Xóa</span></span></a></div></div>';
								jQuery(pageCartItem).appendTo(table.find('.cart-tbody'));
								if(item.variant_title == 'Default Title'){
									$('.variant-title').hide();
								}
							}); 
							jQuery(pageCartCheckout).appendTo(table.children('.cart'));
						}else {
							jQuery('<p class="hidden-xs-down">Không có sản phẩm nào trong giỏ hàng. Quay lại <a href="/" style="color:#de0031;">cửa hàng</a> để tiếp tục mua sắm.</p>').appendTo(table);
							jQuery('.cart_desktop_page').css('min-height', 'auto');
						}
					}
				});
			}
		}
		updateCartDesc(cart);
		jQuery('#wait').hide();
	}
	Bizweb.updateCartPopupForm = function(cart, cart_summary_id, cart_count_id) {
		if ((typeof cart_summary_id) === 'string') {
			var cart_summary = jQuery(cart_summary_id);
			if (cart_summary.length) {
				// Start from scratch.
				cart_summary.empty();
				// Pull it all out.        
				jQuery.each(cart, function(key, value) {
					if (key === 'items') {
						var table = jQuery(cart_summary_id);           
						if (value.length) { 
							jQuery.each(value, function(i, item) {
								var buttonQty = "";
								if(item.quantity == '1'){
									buttonQty = 'disabled';
								}else{
									buttonQty = '';
								}
								var link_img3 = Bizweb.resizeImage(item.image, 'small');
								if(link_img3=="null" || link_img3 =='' || link_img3 ==null){
									link_img3 = 'https://bizweb.dktcdn.net/thumb/large/assets/themes_support/noimage.gif';
								}
								var pageCartItem = '<div data-id="productid-'+ item.variant_id +'" class="item-popup  productid-' + item.variant_id +'"><div style="width: 52%;" class="item_prolist text-left text-left-xs"><div class="item-image">'
								+ '<a class="product-image" href="' + item.url + '" title="' + item.name + '"><img alt="'+  item.name  + '" src="' + link_img3 +  '"width="'+ '80' +'"\></a>'
								+ '</div><div  class="item-info"><p data-id="' + item.name + '" class="item-name"><a href="' + item.url + '" title="' + item.name + '">' + item.name + '</a></p>'

								+ '<p class="item-remove"><a href="javascript:;" class="remove-item-cart" title="Xóa" data-id="'+ item.variant_id +'"><i class="fa fa-times"></i><span class="hidden_mobile delete-pro">Bỏ sản phẩm</span></a></p><p class="addpass" style="color:#fff;">'+ item.variant_id +'</p></div></div>'
								+ '<div style="width: 15%;" class="price_mobile text-right text-right-xs"><div class="item-price"><span class="price">' + Bizweb.formatMoney(item.price, "{{amount_no_decimals_with_comma_separator}}₫") + '</span>'
								+ '</div></div><div style="width: 15%;" class="input_mobile text-right text-center-xs"><input class="variantID" type="hidden" name="variantId" value="'+ item.variant_id +'">'
								+ '<button onClick="var result = document.getElementById(\'qtyItem'+ item.variant_id +'\'); var qtyItem'+ item.variant_id +' = result.value; if( !isNaN( qtyItem'+ item.variant_id +' ) &amp;&amp; qtyItem'+ item.variant_id +' &gt; 1 ) result.value--;return false;" ' + buttonQty + ' class="reduced_pop items-count btn-minus" type="button">–</button>'
								+ '<input type="text" maxlength="12" min="0" class="input-text number-sidebar input_pop qtyItem'+ item.variant_id +'" id="qtyItem'+ item.variant_id +'" name="Lines" id="updates_'+ item.variant_id +'" size="4" value="'+ item.quantity +'">'
								+ '<button onClick="var result = document.getElementById(\'qtyItem'+ item.variant_id +'\'); var qtyItem'+ item.variant_id +' = result.value; if( !isNaN( qtyItem'+ item.variant_id +' )) result.value++;return false;" class="increase_pop items-count btn-plus" type="button">+</button></div>'
								+ '<div style="width: 18%;" class="text-right text-right-xs2"><span class="cart-price"> <span class="price">'+ Bizweb.formatMoney(item.price * item.quantity, "{{amount_no_decimals_with_comma_separator}}₫") +'</span> </span></div></div>';
								jQuery(pageCartItem).appendTo(table);
								if(item.variant_title == 'Default Title'){
									$('.variant-title-popup').hide();
								}

							}); 
						}
					}
				});
			}
		}

		jQuery('.total-price').html(Bizweb.formatMoney(cart.total_price, "{{amount_no_decimals_with_comma_separator}}₫"));
		updateCartDesc(cart);
	}
	Bizweb.updateCartPageFormMobile = function(cart, cart_summary_id, cart_count_id) {
		if ((typeof cart_summary_id) === 'string') {
			var cart_summary = jQuery(cart_summary_id);
			if (cart_summary.length) {
				// Start from scratch.
				cart_summary.empty();
				// Pull it all out.        
				jQuery.each(cart, function(key, value) {
					if (key === 'items') {

						var table = jQuery(cart_summary_id);           
						if (value.length) {   
							jQuery('<div class="cart_page_mobile max767 content-product-list"></div>').appendTo(table);
							jQuery.each(value, function(i, item) {
								jQuery('<div class="item-product item productid-' + item.variant_id +' "><div class="item-product-cart-mobile"><a href="' + item.url + '">	<a class="product-images" href=""  title="' + item.name + '"><img width="80" height="150" alt="" src="' + Bizweb.resizeImage(item.image, 'small') +  '" alt="' + item.name + '"></a></a></div>'
									   + '<div class="title-product-cart-mobile"><h3><a href="' + item.url + '" title="' + item.name + '">' + item.name + '</a></h3><p>Giá: <span>' + Bizweb.formatMoney(item.price, "{{amount_no_decimals_with_comma_separator}}₫") + '</span></p></div>'
									   + '<div class="select-item-qty-mobile"><div class="txt_center">'
									   + '<input class="variantID" type="hidden" name="variantId" value="'+ item.variant_id +'"><button onClick="var result = document.getElementById(\'qtyMobile'+ item.variant_id +'\'); var qtyMobile'+ item.variant_id +' = result.value; if( !isNaN( qtyMobile'+ item.variant_id +' ) &amp;&amp; qtyMobile'+ item.variant_id +' &gt; 0 ) result.value--;return false;" class="reduced items-count btn-minus" type="button">–</button><input type="text" maxlength="12" min="0" class="input-text number-sidebar qtyMobile'+ item.variant_id +'" id="qtyMobile'+ item.variant_id +'" name="Lines" id="updates_'+ item.variant_id +'" size="4" value="'+ item.quantity +'"><button onClick="var result = document.getElementById(\'qtyMobile'+ item.variant_id +'\'); var qtyMobile'+ item.variant_id +' = result.value; if( !isNaN( qtyMobile'+ item.variant_id +' )) result.value++;return false;" class="increase items-count btn-plus" type="button">+</button></div>'
									   + '<a class="button remove-item remove-item-cart" href="javascript:;" data-id="'+ item.variant_id +'">Xoá</a></div>').appendTo(table.children('.content-product-list'));

								});
							
							jQuery('<div class="header-cart-price" style=""><div class="title-cart "><h3 class="text-xs-left">Tổng tiền</h3><a class="text-xs-right totals_price_mobile">' + Bizweb.formatMoney(cart.total_price, "{{amount_no_decimals_with_comma_separator}}₫") + '</a></div>'
								  	+ '<div class="checkout"><button class="btn-proceed-checkout-mobile" title="Tiến hành thanh toán" type="button" onclick="window.location.href=\'/checkout\'">'
								  	+ '<span>Tiến hành thanh toán</span></button></div></div>').appendTo(table);
						}
						
					}
				});
			}
		}
		updateCartDesc(cart);
	}
	
	
	function updateCartDesc(data){
		var $cartPrice = Bizweb.formatMoney(data.total_price, "{{amount_no_decimals_with_comma_separator}}₫"),
			$cartMobile = $('#header .cart-mobile .quantity-product'),
			$cartDesktop = $('.count_item_pr'),
			$cartDesktopList = $('.cart-counter-list'),
			$cartPopup = $('.cart-popup-count');

		switch(data.item_count){
			case 0:
				$cartMobile.text('0');
				$cartDesktop.text('0');
				$cartDesktopList.text('0');
				$cartPopup.text('0');

				break;
			case 1:
				$cartMobile.text('1');
				$cartDesktop.text('1');
				$cartDesktopList.text('1');
				$cartPopup.text('1');

				break;
			default:
				$cartMobile.text(data.item_count);
				$cartDesktop.text(data.item_count);
				$cartDesktopList.text(data.item_count);
				$cartPopup.text(data.item_count);

				break;
		}
		$('.top-cart-content .top-subtotal .price, aside.sidebar .block-cart .subtotal .price, .popup-total .total-price').html($cartPrice);
		$('.popup-total .total-price').html($cartPrice);
		$('.shopping-cart-table-total .totals_price').html($cartPrice);
		$('.header-cart-price .totals_price_mobile').html($cartPrice);
		$('.cartCount').html(data.item_count);
	}
	
	Bizweb.onCartUpdate = function(cart) {
		Bizweb.updateCartFromForm(cart, '.mini-products-list');
		Bizweb.updateCartPopupForm(cart, '#popup-cart-desktop .tbody-popup');
		
	};
	Bizweb.onCartUpdateClick = function(cart, variantId) {
		jQuery.each(cart, function(key, value) {
			if (key === 'items') {    
				jQuery.each(value, function(i, item) {	
					if(item.variant_id == variantId){
						$('.productid-'+variantId).find('.cart-price span.price').html(Bizweb.formatMoney(item.price * item.quantity, "{{amount_no_decimals_with_comma_separator}}₫"));
						$('.productid-'+variantId).find('.items-count').prop("disabled", false);
						$('.productid-'+variantId).find('.number-sidebar').prop("disabled", false);
						$('.productid-'+variantId +' .number-sidebar').val(item.quantity);
						if(item.quantity == '1'){
							$('.productid-'+variantId).find('.items-count.btn-minus').prop("disabled", true);
						}
					}
				}); 
			}
		});
		updateCartDesc(cart);
	}
	Bizweb.onCartRemoveClick = function(cart, variantId) {
		jQuery.each(cart, function(key, value) {
			if (key === 'items') {    
				jQuery.each(value, function(i, item) {	
					if(item.variant_id == variantId){
						$('.productid-'+variantId).remove();
					}
				}); 
			}
		});
		updateCartDesc(cart);
	}
	$(window).ready(function(){
		$.ajax({
			type: 'GET',
			url: '/cart.js',
			async: false,
			cache: false,
			dataType: 'json',
			success: function (cart){
				Bizweb.updateCartFromForm(cart, '.mini-products-list');
				Bizweb.updateCartPopupForm(cart, '#popup-cart-desktop .tbody-popup'); 
				
			}
		});
	});
	
</script>

	<script type="text/javascript">

	Bizweb.updateCartFromForm = function(cart, cart_summary_id, cart_count_id) {
		var dqminicart = $('#cart-sidebar');
		if ((typeof cart_summary_id) === 'string') {
			var cart_summary = jQuery(cart_summary_id);
			if (cart_summary.length) {
				dqminicart.addClass('hasclass');
				// Start from scratch.
				cart_summary.find('.list-item ul').empty();

				// Pull it all out.        
				jQuery.each(cart, function(key, value) {

					if (key === 'items') {

						var table = jQuery(cart_summary_id);           
						if (value.length) { 
							dqminicart.addClass('hasclass');
							jQuery.each(value, function(i, item) {	
								var link_img = Bizweb.resizeImage(item.image, 'small');if(link_img=="null" || link_img =='' || link_img ==null){link_img = 'http://bizweb.dktcdn.net/thumb/large/assets/themes_support/noimage.gif';}  
								var buttonQty = "";

								 jQuery(cart_summary_id).find('.list-item ul').append(
									 '<li class="item productid-' + item.variant_id +'">'
									 +'<a class="product-image" href="' + item.url + '" title="' + item.name + '"><img class="anh-img" alt="'+  item.name  + '" src="' + link_img +  '"width="'+ '100' +'"\></a>'
									 +'<div class="detail-item"><div class="product-details"> '
									 +'<a href="javascript:void(0);" title="Xóa" onclick="Bizweb.removeItem(' + item.variant_id + ')" class="fa fa-trash">&nbsp;</a>'
									 +'<p class="product-name"> <a href="' + item.url + '" title="' + item.name + '">' + item.name + '</a></p></div>'
									 +'<div class="product-details-bottom"> <span class="price2">&nbsp;'+ '<b class="cartCountItem"></b>' + item.quantity + '&nbsp;x&nbsp;' + Bizweb.formatMoney(item.price, "{{amount_no_decimals_with_comma_separator}}₫") + '</span> '
									 + '<div class="quantity-select"><input  class="variantID" type="hidden" name="variantId" value="'+ item.variant_id +'"><button onClick="var result = document.getElementById(\'qty'+ item.variant_id +'\'); var qty'+ item.variant_id +' = result.value; if( !isNaN( qty'+ item.variant_id +' ) &amp;&amp; qty'+ item.variant_id +' &gt; 1 ) result.value--;return false;" class="reduced items-count btn-minus" ' + buttonQty + ' type="button"><i class="fa fa-chevron-down" aria-hidden="true"></i></button><input type="text" maxlength="12" min="0" class="input-text input_drop_cart number-sidebar qty'+ item.variant_id +'" id="qty'+ item.variant_id +'" name="Lines" id="updates_'+ item.variant_id +'" size="1" value="'+ item.quantity +'"><button onClick="var result = document.getElementById(\'qty'+ item.variant_id +'\'); var qty'+ item.variant_id +' = result.value; if( !isNaN( qty'+ item.variant_id +' )) result.value++;return false;" class="increase items-count btn-plus" type="button"><i class="fa fa-chevron-up" aria-hidden="true"></i></button></div> </div></div></li>'

								 )


								}); 


								cart_summary.find('.price').html(Bizweb.formatMoney(cart.total_price, "{{amount_no_decimals_with_comma_separator}}₫"));

							}
										else {
										dqminicart.removeClass('hasclass');
							cart_summary.find('.list-item ul').empty();
							jQuery(cart_summary_id).find('.list-item ul').append('<li class="item"><p>Không có sản phẩm nào trong giỏ hàng.</p></li>');


						}

					}
				});

			}
			else{
				dqminicart.removeClass('hasclass');
			}
		}
		updateCartDesc(cart);
	}
	
	
	function updateCartDesc(data){
		var $cartLinkText = $('.mini-cart .cartCount'),

			$cartPrice = Bizweb.formatMoney(data.total_price, "{{amount_no_decimals_with_comma_separator}}₫");		
		switch(data.item_count){
			case 0:
				$cartLinkText.text('0');

				break;
			case 1:
				$cartLinkText.text('1');

				break;
			default:
				$cartLinkText.text(data.item_count);

				break;
		}
		$('.top-cart-content .top-subtotal .price, aside.sidebar .block-cart .subtotal .price, .popup-total .total-price, .shopping-cart-table-total .totals_price, .header-cart-price .totals_price_mobile').html($cartPrice);
	}  
	Bizweb.onCartUpdate = function(cart) {
		Bizweb.updateCartFromForm(cart, '.top-cart-content .mini-products-list', 'shopping-cart');
	};  
	$(window).load(function() {
		// Let's get the cart and show what's in it in the cart box.  
		Bizweb.getCart(function(cart) {      
			Bizweb.updateCartFromForm(cart, '.top-cart-content .mini-products-list');    
		});
	});
</script>

<script>

</script>
	<div id="productReviewPopup" class="hidden">
		<div class="tooltip_name">Bàn cafe tròn gỗ Veneer</div>
		<div class="tooltip_picture">
			<img src="//bizweb.dktcdn.net/thumb/medium/100/012/336/products/06012281%5b1%5d.jpg?v=1442027638377" title="Bàn cafe tròn gỗ Veneer" alt="Bàn cafe tròn gỗ Veneer">
		</div>
	</div>
	<a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 0;"></span></a>
<script src='//bizweb.dktcdn.net/100/183/542/themes/548520/assets/appbulk-product-statistics.js?1542697260528' type='text/javascript'></script>
<div id="facebook-inbox">
	<button class="facebook-inbox-tab" style="display: block; ">
		<span class="facebook-inbox-tab-icon">
			<img src="https://facebookinbox.bizwebapps.vn/Content/Images/fb-icon-1.png" alt="Facebook Chat" />
		</span>
		<span class="facebook-inbox-tab-title">chat với chúng tôi</span>
	</button>

	<div id="facebook-inbox-frame">
		<div id="fb-root">&nbsp;</div>
		<div class="fb-page" data-adapt-container-width="true" data-hide-cover="false" data-href="" data-show-facepile="true" data-small-header="true" data-width="250" data-height="350" data-tabs="messages">
			<div class="fb-xfbml-parse-ignore">
				<blockquote cite=""><a href="">Chat với chúng tôi</a></blockquote>
			</div>
		</div>
	</div>
</div>

<style>
	#facebook-inbox {
		position: fixed;
		bottom: 0px;
		z-index: 110000;
		text-align: center;
		display: none;
	}

	.facebook-inbox-tab-icon {
		float: left;
	}

	.facebook-inbox-tab-title {
		float: left;
		margin-left: 10px;
		line-height: 25px;
	}

	#facebook-inbox-frame {
		display: none;
		width: 100%;
		min-height: 200px;
		overflow: hidden;
		position: relative;
		background-color: #f5f5f5;
	}

	#fb-root {
		height: 0px;
	}

	.facebook-inbox-tab {
		top: 0px;
		bottom: 0px;
		margin: -40px 0px 0px 0px;
		position: relative;
		height: 40px;
		width: 250px;
		border: 1px solid;
		border-radius: 0px 0px 0px 0px;
		text-align: center;
		background-color: #19a3dd;
		color: #ffffff;
	}
</style>
<script>
(function (d, s, id) {
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) return;
				js = d.createElement(s); js.id = id;
				js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.5";
				fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));
	window.facebookParse = function facebookParse(){
		FB.XFBML.parse();
	}
</script> </body>

</html>